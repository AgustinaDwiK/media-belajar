@extends('layouts.main')

@section('container')
    <h1>Coding Yuk - HOME</h1>
    <h2><strong>Beranda</strong></h2>
    <p>Halaman Utama User </p>
@endsection

