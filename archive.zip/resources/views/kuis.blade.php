@extends('layouts.main')

@section('container')
    <h1>Coding Yuk - Quiz</h1>
    <p>Quiz yang disediakan pada website ini</p>
@endsection
